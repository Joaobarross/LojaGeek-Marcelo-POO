package Media;

public class DvdPlayer {
	String nome;
	String tipo;
	String fabricante;
	
	void dadosDvdPlayer(){
		nome = "Sony BDP-S6700";
		tipo = "Blu-ray";
		fabricante = "Sony";
		System.out.println("Nome: " + nome +"\nTipo: " + tipo + "\nFabricante: " + fabricante);
		System.out.println("-----------------------------------");
	}
	void reproduzirDvd(){
		
	}
}
