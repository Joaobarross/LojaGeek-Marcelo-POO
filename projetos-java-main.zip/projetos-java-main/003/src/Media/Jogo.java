package Media;

public class Jogo {
	String nome;
	String lancamento;
	String produtora;
	
	void dadosJogo(){
		nome = "Diablo 3";
		lancamento = "2012";
		produtora = "Blizzard";
		System.out.println("Nome: " + nome +"\nAno: " + lancamento + "\nProdutora: " + produtora);
		System.out.println("-----------------------------------");
	}
	void tipoJogo(){
		
	}
}
