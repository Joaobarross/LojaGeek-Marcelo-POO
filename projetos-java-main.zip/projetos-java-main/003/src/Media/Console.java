package Media;

public class Console {
	String nome;
	String lancamento;
	String fabricante;
	
	void dadosConsole(){
		nome = "X box one x";
		lancamento = "2018";
		fabricante = "Microsoft";
		System.out.println("Nome: " + nome +"\nAno: " + lancamento + "\nFabricante: " + fabricante);
	}
	void executarJogo(){
		
	}
}
