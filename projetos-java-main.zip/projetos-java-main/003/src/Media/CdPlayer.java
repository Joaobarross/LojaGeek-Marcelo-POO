package Media;

public class CdPlayer {
	String nome;
	String tipo;
	String fabricante;
	
	void dadosDvdPlayer(){
		nome = "ONKYO DXC390 ";
		tipo = "CD PLAYER";
		fabricante = "ONKYO";
		System.out.println("Nome: " + nome +"\nTipo: " + tipo + "\nFabricante: " + fabricante);
		System.out.println("-----------------------------------");
	}
	void reproduzirCd(){
		
	}
		
}
